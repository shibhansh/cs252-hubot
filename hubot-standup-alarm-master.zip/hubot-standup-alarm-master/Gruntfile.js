module.exports = function (grunt) {
	'use strict';

	grunt.loadNpmTasks('grunt-release');
};
